## Docker UCP Installation

docker image pull docker/ucp:2.2.7
docker container run --rm -it --name ucp \
-v /var/run/docker.sock:/var/run/docker.sock \
docker/ucp:2.2.7 install \
--host-address 35.185.102.117 \
--interactive