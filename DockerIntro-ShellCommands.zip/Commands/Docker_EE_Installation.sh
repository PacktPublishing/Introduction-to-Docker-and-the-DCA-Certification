## Docker EE Installation

sudo apt-get update
sudo apt-get install \
apt-transport-https \
ca-certificates \
curl \
software-properties-common
$DOCKER_EE_URL=”https://storebits.docker.com/ee/trial/sub-5b858750-62d9-421a-87
44-75af885e3d41”
curl -fsSL "${DOCKER_EE_URL}/ubuntu/gpg" | sudo apt-key add -
sudo apt-key fingerprint 6D085F96
sudo add-apt-repository \
"deb [arch=amd64] $DOCKER_EE_URL/ubuntu \
$(lsb_release -cs) \
stable-17.06"
sudo apt-get update
sudo apt-get install docker-ee
sudo docker run hello-world
sudo groupadd docker
sudo usermod -ag docker vitthal
docker images