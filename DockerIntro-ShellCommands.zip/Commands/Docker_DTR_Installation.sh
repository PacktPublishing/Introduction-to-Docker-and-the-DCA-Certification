## Docker DTR Installation

docker pull docker/dtr:2.4.3
docker run -it --rm docker/dtr instal \
--ucp-node worker-1 \
--ucp-insecure-tls